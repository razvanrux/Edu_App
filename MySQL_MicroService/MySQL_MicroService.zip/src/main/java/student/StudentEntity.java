package student;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "date_studenti")
@Getter
@Setter
public class StudentEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(nullable = false)
    private String nume;

    @Column(nullable = false)
    private String prenume;

    @Column(unique = true, nullable = false)
    private String email;

    @Enumerated(EnumType.STRING)
    @Column(name = "ciclu_studii", nullable = false)
    private CicluStudii cicluStudii;

    @Column(name = "an_studiu", nullable = false)
    private int anStudiu;

    @Column(nullable = false)
    private int grupa;

    public enum CicluStudii {
        LICENTA, MASTER
    }
    @Override
    public String toString() {
        return "StudentEntity{" +
                "id=" + id +
                ", nume='" + nume + '\'' +
                ", prenume='" + prenume + '\'' +
                ", email='" + email + '\'' +
                ", cicluStudii=" + cicluStudii +
                ", anStudiu=" + anStudiu +
                ", grupa=" + grupa +
                '}';
    }
}
